@foreach ($list as $row)
      {{$row->customer}} <br>
@endforeach
