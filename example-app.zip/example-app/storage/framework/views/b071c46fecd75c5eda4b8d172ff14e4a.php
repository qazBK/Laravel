<div>
    <ul class="borderlist">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li wire:key="<?php echo e($item->id); ?>"> 
            <?php echo e($item->title); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->    
    <ul>
</div><?php /**PATH C:\Users\Boliyarskih K\Desktop\Laravel\example-app\resources\views/livewire/listcolors.blade.php ENDPATH**/ ?>