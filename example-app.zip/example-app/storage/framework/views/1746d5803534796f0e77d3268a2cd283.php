<div>
<li> 
        <input type="text" x-ref="title_row_<?php echo e($item->id); ?>" value="<?php echo e($item->title); ?>"
        wire:change.debounce="update_color_id('<?php echo e($item->id); ?>', $refs.title_row_<?php echo e($item->id); ?>.value)">
        <a href="#" wire:confirm="Точно удаляем?" wire:click.prevent="delete_color('<?php echo e($item->id); ?>')">x</a>
</li>
</div><?php /**PATH C:\Users\Boliyarskih K\Desktop\Laravel\example-app\resources\views/livewire/color-row.blade.php ENDPATH**/ ?>