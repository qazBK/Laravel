<div>
    <h1><?php echo e($count); ?></h1>
 
    <button wire:click="increment">+</button>
 
    <button wire:click="decrement">-</button>

    <form wire:submit="save">
        <input type="text" wire:model="title">
        <button type="submit">Записать</button>
    </form>

    Список Color: 

<form wire:submit="create_color">
    <input type="text" wire:model="title_color">
    <button type="submit" >Создать новый Цвет</button>
</form>

<ul>
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li wire:key="<?php echo e($item->id); ?>"> 
            <!--[if BLOCK]><![endif]--><?php if($item->id == $active_edit_color): ?>    
                <input type="text" wire:model="newValue">
                <button wire:click="update_color('<?php echo e($item->id); ?>')">Записать</button>
                <button type="button" wire:confirm="Точно удаляем?" wire:click="delete_color('<?php echo e($item->id); ?>')"> Удалить </button>
            <?php else: ?>
                <?php echo e($item->title); ?>

                <button type="button" wire:click="edit_color('<?php echo e($item->id); ?>')" > Редактировать </button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->    

    <h2>Список с правкой всего сразу через $refs</h2>
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li wire:key="<?php echo e($item->id); ?>"> 
                <input type="text" x-ref="title_<?php echo e($item->id); ?>" value="<?php echo e($item->title); ?>"
                wire:change.debounce="update_color_id('<?php echo e($item->id); ?>', $refs.title_<?php echo e($item->id); ?>.value)">
                <a href="#" wire:confirm="Точно удаляем?" wire:click.prevent="delete_color('<?php echo e($item->id); ?>')">x</a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->    
    </ul>

    <hr>

    <h2>Список из вложенных компонентов</h2>
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($item->title); ?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('color-row', ['item' => $item]);

$__html = app('livewire')->mount($__name, $__params, $item->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->    
    </ul>
   <ul>
</div>
<?php /**PATH C:\Users\Boliyarskih K\Desktop\Laravel\example-app\resources\views/livewire/counter.blade.php ENDPATH**/ ?>