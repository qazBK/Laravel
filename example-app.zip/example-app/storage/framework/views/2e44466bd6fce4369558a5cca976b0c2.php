<!--  https://laravel.su/docs/11.x/blade#rassirenie-maketa -->

<?php $__env->startSection('title'); ?>
Список машин
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
Список машин
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div>
<div class="p-2">
    <a class="btn btn-primary" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Форма добавления
    </a>
  </div>
  <div class="collapse" id="collapseExample">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create'],\App\Model\Car::class)): ?>

<form action="?data=send" method="post">
    <?php echo csrf_field(); ?>
    <div>
        <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div>Ошибка: <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <label for="brand">brand: </label>
      <input type="text" name="brand"
       id="brand" <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> style="background-color: yellow;" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
       value="<?php echo e(old('brand')); ?>"
       />
    </div>
    <div>
        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div>Ошибка: <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <label for="color">color: </label>


      <select name="color" id="color" <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> style="background-color: yellow;" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
         <option value="" >Выберите цвет</option>
         <?php $__currentLoopData = $list_color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <option value="<?php echo e($row->id); ?>"><?php echo e($row->title); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>

    </div>
    <div>
        <?php $__errorArgs = ['nambo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div>Ошибка: <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      <label for="nambo">nambo: </label>
      <input type="text" name="nambo"  <?php $__errorArgs = ['nambo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> style="background-color: yellow;" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
       id="nambo"
       value="<?php echo e(old('nambo')); ?>"
        />
    </div>
    <div>
      <input class="w-50 btn btn-primary btn-lg" type="submit"
       value="Записать машину" />
    </div>-
</form>

<?php endif; ?>
</div>
<h3>Список машин:</h3>
<div>
        <table class="table">
            <thead>
<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr> 
                    <th scope="row">#</th>
                    <td><?php echo e($row->brand); ?>.</td>
                    <td><?php echo e($row->color->title); ?>.</td>
                    <td><?php echo e($row->nambo); ?>.</td>
                    <td><a class="btn btn-outline-danger" role="button" href="<?php echo e(route('car.delete',['id' => $row->id])); ?>"> [Удалить]</a></td>
                </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</thead>
        <table>
    </div>

<h3>Динамический запрос:</h3>
  <ul id="car-list">
    
  </ul>
  <script>

CarListItem = document.querySelector('#car-list');

function item_add(data) {
  let li = document.createElement("li");
  li.innerText = data.nambo+" "+data.color.title;
  CarListItem.appendChild(li);
}

  function Car_List() {

    console.dir('Запрос');

    fetch('<?php echo e(route('api.car.index')); ?>', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        },
      })

      .then(response => {
        console.dir(response);
        return response.json();
      })

      .then(data_out => {
        console.dir(data_out);
        data_out.forEach((item) => item_add(item));
      });
  }


  let data = {};
  Car_List();

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Boliyarskih K\Desktop\Laravel\example-app\resources\views/cars.blade.php ENDPATH**/ ?>